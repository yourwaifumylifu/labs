//      ЗАДАНИЕ 1
// 
// var element = document.getElementById("divMain").children;
// var arr = [];
// var i = -1;

// function findAllPSiblings(where) {
//     i++;
//     if (i == where.length - 1) {
//         return null;
//     }
//     else if (where[i].nextElementSibling.nodeName === 'P') {
//         if(where[i].nodeName != 'P') 
//         arr.push(where[i]);
//         findAllPSiblings(where);
//     }
//     else {
//         findAllPSiblings(where);
//     }      
// }

// findAllPSiblings(element);
// console.log(arr)

//      ЗАДАНИЕ 2

// var element = document.getElementById("divMain");

// function deleteTextNodes(where) {
//     var w = where.childNodes;
//     for (var i = 0; i < w.length; i++) {
//         if (w[i].nodeType === 3) {
//             w[i].parentNode.removeChild(w[i]);
//         }
//     }
// }

// deleteTextNodes(element);

// //      ЗАДАНИЕ 3

// function clickFunction() {
//     document.getElementById("demo").innerHTML = "Hello World";
//     removeEventListener('click', clickFunction);

// };
// function once(target, fn) {
//     target.addEventListener("click",fn);
// }

// once(document.getElementById("myBtn"),clickFunction);