// // TASK 1

// function returnFirstArgument(arg) {
//     console.log(arg);
//     return arg;
// }
// var x = 10;
// returnFirstArgument(x);

// function bindFunction(fn, arg) {
//     console.log(fn(arg));
// }
// bindFunction(returnFirstArgument,10);

// TASK 2
function forEach(testArr, arr) {
    for (var i = 0; i < arr.length; i++) {
        testArr = arr[i];
        console.log(testArr);
    }
}

array = [1,2,3,4,5];
var test;
forEach(test, array);

// TASK 3
var object = {
    "color" : "red",
    "opacity" :"0.9"
};

function deleteProperty(test, prop) {
    delete test[prop];
}

deleteProperty(object, "color");
console.log(object);

let toPow = {
    set: function(obj, prop, value) {
        if (!Number.isInteger(value)) {
            throw new TypeError('The value is not an integer');
        } else {
            value = value * value;
        }
        obj[prop] = value;
        return true;
    }
};

function createProxy(obj) {
    return new Proxy(obj, toPow);
}

let obj = createProxy(object);

obj.num1 = 20;
console.log(obj.num1);

obj.num2 = 10;
console.log(obj.num2);